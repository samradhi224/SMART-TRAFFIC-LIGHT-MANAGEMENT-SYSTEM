/*
  SMART FOUR-ROAD TRAFFIC MANAGEMENT SYSTEM
  Board: Arduino UNO R3
  Simulation: Wokwi / Arduino IDE

  ROAD INDEX:
    0 = North, 1 = East, 2 = South, 3 = West

  HARDWARE:
    - 4 x HC-SR04 ultrasonic sensors (one sensor for each road)
    - 2 x 74HC595 shift registers connected in cascade
    - 12 LEDs: Red, Yellow and Green for each road
    - 12 x 220-ohm current-limiting resistors

  MAIN FUNCTIONS:
    1. Sensor reading: checks whether an object/vehicle is close to each sensor.
    2. Traffic model: estimates arrivals and maintains a simulated queue.
    3. Signal controller: selects a road and runs Green, Yellow and All-Red phases.
    4. Accident: reduces the affected road's service capacity and diverts arrivals.
    5. Blockage: reduces capacity further and diverts arrivals.
    6. Pedestrian: inserts an all-vehicle-red crossing phase.
    7. VIP: gives the selected road priority and a longer green phase.
    8. Violations: logs red-light, wrong-way and speeding events.
    9. Fuel: compares estimated idling fuel for fixed-time and intelligent models.

  IMPORTANT LIMITATIONS:
    - Accident, blockage, pedestrian, VIP and violation events are activated
      with Serial Monitor commands; they are not automatically detected.
    - HC-SR04 detects nearby objects/presence, not the exact number of vehicles.
    - Traffic diversion is a simplified model, not GPS/map route planning.
    - Fuel use is estimated in software; no fuel sensor is connected.
    - This is an educational simulation, not a real traffic-light controller.
*/

// -----------------------------------------------------------------------------
// 1. ARDUINO PIN CONFIGURATION
// -----------------------------------------------------------------------------

// The two 74HC595 chips share clock and latch pins.
// The first chip's data output (Q7S) connects to the second chip's DS input.
const byte SR_DATA  = 2;  // Arduino D2 -> DS (SER, pin 14) of first 74HC595
const byte SR_CLOCK = 3;  // Arduino D3 -> SHCP (SRCLK, pin 11) of both chips
const byte SR_LATCH = 4;  // Arduino D4 -> STCP (RCLK, pin 12) of both chips

// One trigger/echo pair for each road's HC-SR04 sensor.
const byte trigPin[4] = {5, 7, 9, 11};   // TRIG: North, East, South, West
const byte echoPin[4] = {6, 8, 10, 12}; // ECHO: North, East, South, West

const char* roadName[4] = {"North", "East", "South", "West"};

// -----------------------------------------------------------------------------
// 2. TRAFFIC AND INCIDENT VARIABLES
// Array index 0=North, 1=East, 2=South, 3=West.
// -----------------------------------------------------------------------------

bool accident[4]   = {false, false, false, false}; // Accident flag per road
bool blocked[4]    = {false, false, false, false}; // Road/lane blockage flag
bool pedWaiting[4] = {false, false, false, false}; // Pedestrian request flag
bool vip[4]        = {false, false, false, false}; // VIP convoy flag

int demand[4] = {2, 2, 2, 2};         // Simulated demand level, 0 to 10
int queueVehicles[4] = {0, 0, 0, 0}; // Estimated queue for each road
int convoySize[4] = {0, 0, 0, 0};    // Number of vehicles in simulated VIP convoy

// Traffic signal states. Only one road may have GREEN at a time.
enum Phase { ALL_RED, GREEN, YELLOW, PEDESTRIAN };
Phase phase = ALL_RED;

int activeRoad = -1;       // Road currently receiving green; -1 means none
int nextRoad = 0;           // Starting point for fair road selection
int pedestrianRoad = -1;    // Road whose pedestrian crossing is active

// Timers use millis() so the Arduino can continue processing other tasks.
unsigned long phaseStarted = 0;
unsigned long modelTick = 0;
unsigned long statusTick = 0;

unsigned long greenDuration = 7000;
const unsigned long yellowDuration = 2000;
const unsigned long allRedDuration = 800;
const unsigned long pedestrianDuration = 5000;

// Counters and estimated fuel model.
unsigned long totalArrivals = 0;
unsigned long totalServed = 0;
unsigned long intelligentIdleVehicleSeconds = 0;
unsigned long fixedIdleVehicleSeconds = 0;

// Illustrative idling rate: 0.6 litres/hour = 0.000167 litres/vehicle/second.
const float FUEL_L_PER_VEHICLE_SECOND = 0.000167f;

// 16 output bits for two cascaded 74HC595 chips; 12 bits are used by LEDs.
uint16_t ledBits = 0;

// -----------------------------------------------------------------------------
// 3. SHIFT REGISTER AND TRAFFIC LED FUNCTIONS
// -----------------------------------------------------------------------------

// Send all 16 bits to the two 74HC595 chips.
// The latch stays LOW while shifting data, then HIGH to update the LED outputs.
void writeShiftRegisters() {
  digitalWrite(SR_LATCH, LOW);
  shiftOut(SR_DATA, SR_CLOCK, MSBFIRST, (byte)(ledBits >> 8));   // High byte
  shiftOut(SR_DATA, SR_CLOCK, MSBFIRST, (byte)(ledBits & 0xFF)); // Low byte
  digitalWrite(SR_LATCH, HIGH);
}

// Change one LED bit in memory.
// colour: 0=Red, 1=Yellow, 2=Green.
// Each road uses three consecutive output bits.
void setLamp(byte road, byte colour, bool on) {
  byte bitNo = road * 3 + colour;
  if (on) ledBits |= (1U << bitNo);       // Set bit to 1: LED ON
  else    ledBits &= ~(1U << bitNo);      // Clear bit to 0: LED OFF
}

// Safety state: all four red LEDs ON; all yellow and green LEDs OFF.
void setAllRed() {
  ledBits = 0;
  for (byte r = 0; r < 4; r++) {
    setLamp(r, 0, true);
  }
  writeShiftRegisters();
  phase = ALL_RED;
}

// Turn one selected road GREEN while all other roads remain RED.
// Green duration is adjusted using queue size and incident/VIP conditions.
void setGreen(byte road) {
  setAllRed();                 // First make every road red for safety
  setLamp(road, 0, false);     // Turn selected road's red LED OFF
  setLamp(road, 2, true);      // Turn selected road's green LED ON
  writeShiftRegisters();

  activeRoad = road;
  phase = GREEN;
  phaseStarted = millis();

  // More queued vehicles means a longer green time, limited to 5-15 seconds.
  int seconds = 5 + queueVehicles[road] / 2;
  greenDuration = constrain(seconds * 1000L, 5000L, 15000L);

  // Incident roads receive shorter green time in this simplified model.
  if (blocked[road])  greenDuration = max(4000UL, greenDuration - 1500UL);
  if (accident[road]) greenDuration = max(3000UL, greenDuration - 2500UL);

  // A VIP convoy can request at least 10 seconds of green.
  if (vip[road]) greenDuration = max(greenDuration, 10000UL);

  Serial.print(F("EVENT,GREEN,"));
  Serial.println(road);
}

// Change the active road's signal from GREEN to YELLOW.
void beginYellow() {
  if (activeRoad >= 0) {
    setLamp(activeRoad, 2, false); // Green OFF
    setLamp(activeRoad, 1, true);  // Yellow ON
    writeShiftRegisters();
  }
  phase = YELLOW;
  phaseStarted = millis();
}

// -----------------------------------------------------------------------------
// 4. ROAD SELECTION AND SIGNAL PHASE CONTROLLER
// -----------------------------------------------------------------------------

// Select next road using this priority:
// 1. VIP convoy, 2. pedestrian request, 3. highest queue + demand score.
// Incident roads receive a lower score.
int chooseRoad() {
  for (byte k = 0; k < 4; k++) {
    byte r = (nextRoad + k) % 4;
    if (vip[r]) return r;
  }

  for (byte k = 0; k < 4; k++) {
    byte r = (nextRoad + k) % 4;
    if (pedWaiting[r]) return r;
  }

  int best = -1;
  int bestScore = 0;

  for (byte k = 0; k < 4; k++) {
    byte r = (nextRoad + k) % 4;
    int score = queueVehicles[r] + demand[r];

    if (blocked[r])  score -= 3; // Penalty for blocked road
    if (accident[r]) score -= 5; // Larger penalty for accident road

    if (score > bestScore) {
      bestScore = score;
      best = r;
    }
  }
  return best;
}

// Non-blocking traffic-light state machine.
// GREEN -> YELLOW -> ALL_RED -> next road.
// During a pedestrian phase all vehicle approaches remain RED.
void updateController() {
  unsigned long now = millis();

  // End green phase when its timer expires.
  if (phase == GREEN && now - phaseStarted >= greenDuration) {
    beginYellow();
    return;
  }

  // End yellow phase and enter the all-red safety interval.
  if (phase == YELLOW && now - phaseStarted >= yellowDuration) {
    setAllRed();
    phaseStarted = now;
    return;
  }

  // End pedestrian phase and clear that pedestrian request.
  if (phase == PEDESTRIAN && now - phaseStarted >= pedestrianDuration) {
    if (pedestrianRoad >= 0) pedWaiting[pedestrianRoad] = false;

    Serial.print(F("EVENT,PED_DONE,"));
    Serial.println(pedestrianRoad);

    pedestrianRoad = -1;
    setAllRed();
    phaseStarted = now;
    return;
  }

  // After the all-red interval, choose the next road.
  if (phase == ALL_RED && now - phaseStarted >= allRedDuration) {
    int r = chooseRoad();

    if (r >= 0) {
      if (pedWaiting[r]) {
        // No vehicle road receives green during a pedestrian crossing.
        setAllRed();
        phase = PEDESTRIAN;
        pedestrianRoad = r;
        phaseStarted = now;

        Serial.print(F("EVENT,PED_START,"));
        Serial.println(r);
      } else {
        setGreen(r);
        nextRoad = (r + 1) % 4; // Rotate starting point for fairness
      }
    }
  }
}

// -----------------------------------------------------------------------------
// 5. HC-SR04 ULTRASONIC SENSOR FUNCTION
// -----------------------------------------------------------------------------

// Measure distance for one road.
// The sensor sends a short pulse and measures the time taken by the echo.
// Distance = (echo time x speed of sound) / 2; divide by 2 for the return trip.
long readDistanceCm(byte road) {
  digitalWrite(trigPin[road], LOW);
  delayMicroseconds(2);
  digitalWrite(trigPin[road], HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin[road], LOW);

  unsigned long duration = pulseIn(echoPin[road], HIGH, 25000UL);

  if (duration == 0) return 999; // No echo within timeout: treat as far away
  return (long)(duration * 0.0343f / 2.0f);
}

// -----------------------------------------------------------------------------
// 6. TRAFFIC ARRIVAL, QUEUE, ACCIDENT AND BLOCKAGE SIMULATION
// -----------------------------------------------------------------------------

// Runs every two seconds.
// Sensor proximity indicates vehicle/object presence. The DEMAND command
// creates repeatable simulated traffic arrivals because one HC-SR04 cannot
// accurately count every vehicle in a queue.
void updateTrafficModel() {
  unsigned long now = millis();
  if (now - modelTick < 2000UL) return;
  modelTick = now;

  int arrivalsThisTick = 0;
  int diverted[4] = {0, 0, 0, 0};

  // Read each road sensor and calculate its new simulated arrivals.
  for (byte r = 0; r < 4; r++) {
    long distance = readDistanceCm(r);

    // Demand 0-10 is converted to a simple arrival rate.
    int arrivals = demand[r] / 2;

    // A nearby object guarantees at least one arrival for this update.
    if (distance < 35) arrivals = max(arrivals, 1);

    // ACCIDENT/BLOCK: divert a portion of new arrivals away from this road.
    if (accident[r] || blocked[r]) {
      int percent = blocked[r] ? 70 : 60;
      int divertedCount = arrivals * percent / 100;
      arrivals -= divertedCount;

      // Find the next road that is not itself blocked or accident-affected.
      for (byte step = 1; step < 4 && divertedCount > 0; step++) {
        byte alternate = (r + step) % 4;

        if (!blocked[alternate] && !accident[alternate]) {
          diverted[alternate] += divertedCount;

          Serial.print(F("EVENT,DIVERT,"));
          Serial.print(r);
          Serial.print(',');
          Serial.println(alternate);
          break;
        }
      }
    }

    // Add arrivals to this road's queue; cap queue at 80 for the simulation.
    queueVehicles[r] = constrain(queueVehicles[r] + arrivals, 0, 80);
    arrivalsThisTick += arrivals;
  }

  // Add vehicles diverted from incident roads to their alternative roads.
  for (byte r = 0; r < 4; r++) {
    queueVehicles[r] = constrain(queueVehicles[r] + diverted[r], 0, 80);
    arrivalsThisTick += diverted[r];
  }
  totalArrivals += arrivalsThisTick;

  // Only the road currently showing GREEN can serve vehicles.
  for (byte r = 0; r < 4; r++) {
    if (activeRoad == r && phase == GREEN) {
      int capacity = 3;              // Normal road: 3 vehicles per model update
      if (blocked[r]) capacity = 2;  // Blockage lowers capacity
      if (accident[r]) capacity = 1; // Accident lowers capacity further
      if (vip[r]) capacity += convoySize[r]; // VIP convoy gets extra model capacity

      int served = min(queueVehicles[r], capacity);
      queueVehicles[r] -= served;
      totalServed += served;
    }
  }

  // Estimate waiting vehicle-seconds for the intelligent system.
  int totalQueue = 0;
  for (byte r = 0; r < 4; r++) totalQueue += queueVehicles[r];

  intelligentIdleVehicleSeconds += (unsigned long)totalQueue * 2UL;

  // Simple fixed-time comparison baseline: assume 30 seconds waiting
  // for each new arrival. This is a model assumption, not a measurement.
  fixedIdleVehicleSeconds += (unsigned long)arrivalsThisTick * 30UL;
}

// -----------------------------------------------------------------------------
// 7. STATUS AND FUEL ESTIMATION
// -----------------------------------------------------------------------------

// Convert four Boolean flags into a compact 4-bit value.
// Bit 0=North, bit 1=East, bit 2=South, bit 3=West.
byte makeMask(bool values[4]) {
  byte mask = 0;
  for (byte i = 0; i < 4; i++) {
    if (values[i]) mask |= (1 << i);
  }
  return mask;
}

// Print a CSV status record to Serial Monitor once per second.
// It includes signal phase, active road, queues, incident flags, demand,
// estimated fuel and total arrival/served counts.
void sendStatus() {
  unsigned long now = millis();
  long remaining = 0;

  if (phase == GREEN)
    remaining = max(0L, (long)(greenDuration - (now - phaseStarted)) / 1000L);
  else if (phase == YELLOW)
    remaining = max(0L, (long)(yellowDuration - (now - phaseStarted)) / 1000L);
  else if (phase == PEDESTRIAN)
    remaining = max(0L, (long)(pedestrianDuration - (now - phaseStarted)) / 1000L);

  const char* phaseName = "ALL_RED";
  if (phase == GREEN) phaseName = "GREEN";
  if (phase == YELLOW) phaseName = "YELLOW";
  if (phase == PEDESTRIAN) phaseName = "PEDESTRIAN";

  float fixedFuel = fixedIdleVehicleSeconds * FUEL_L_PER_VEHICLE_SECOND;
  float smartFuel = intelligentIdleVehicleSeconds * FUEL_L_PER_VEHICLE_SECOND;
  float saved = max(0.0f, fixedFuel - smartFuel);

  Serial.print(F("STATUS,"));
  Serial.print(phaseName); Serial.print(',');
  Serial.print(activeRoad); Serial.print(',');
  Serial.print(remaining);

  // Four queue sizes: North, East, South, West.
  for (byte i = 0; i < 4; i++) {
    Serial.print(','); Serial.print(queueVehicles[i]);
  }

  // Incident masks: each bit represents one road.
  Serial.print(','); Serial.print(makeMask(accident));
  Serial.print(','); Serial.print(makeMask(blocked));
  Serial.print(','); Serial.print(makeMask(pedWaiting));
  Serial.print(','); Serial.print(makeMask(vip));

  // Four configured traffic demand values.
  for (byte i = 0; i < 4; i++) {
    Serial.print(','); Serial.print(demand[i]);
  }

  Serial.print(','); Serial.print(fixedFuel, 3);
  Serial.print(','); Serial.print(smartFuel, 3);
  Serial.print(','); Serial.print(saved, 3);
  Serial.print(','); Serial.print(totalArrivals);
  Serial.print(','); Serial.println(totalServed);
}

// -----------------------------------------------------------------------------
// 8. SERIAL MONITOR COMMANDS / INCIDENT SIMULATION
// -----------------------------------------------------------------------------

// Commands are entered at 9600 baud with Newline line ending.
// Examples:
//   DEMAND,0,8             -> high simulated demand on North
//   ACCIDENT,1,1           -> activate accident on East
//   ACCIDENT,1,0           -> clear accident on East
//   BLOCK,2,1              -> block South
//   PED,3,1                -> request pedestrian crossing on West
//   VIP,0,1,5              -> activate five-vehicle VIP convoy on North
//   VIOLATION,SPEEDING,3   -> log speeding event on West
//   CLEAR                  -> clear all incident flags
void processCommand(String line) {
  line.trim();
  if (!line.length()) return;

  // Split the command into comma-separated fields.
  String fields[5];
  byte count = 0;
  int start = 0;

  while (count < 5) {
    int comma = line.indexOf(',', start);

    if (comma < 0) {
      fields[count++] = line.substring(start);
      break;
    }

    fields[count++] = line.substring(start, comma);
    start = comma + 1;
  }

  String cmd = fields[0];
  cmd.toUpperCase();

  // CLEAR removes accident, blockage, pedestrian and VIP states.
  if (cmd == "CLEAR") {
    for (byte i = 0; i < 4; i++) {
      accident[i] = false;
      blocked[i] = false;
      pedWaiting[i] = false;
      vip[i] = false;
      convoySize[i] = 0;
    }
    Serial.println(F("EVENT,CLEAR,0"));
    return;
  }

  // VIOLATION commands create event-log entries.
  // This is manual event simulation, not automatic camera-based detection.
  if (cmd == "VIOLATION") {
    Serial.print(F("EVENT,VIOLATION,"));
    Serial.print(fields[1]);
    Serial.print(',');
    Serial.println(constrain(fields[2].toInt(), 0, 3));
    return;
  }

  if (count < 3) {
    Serial.println(F("ERR,BAD_COMMAND"));
    return;
  }

  int road = constrain(fields[1].toInt(), 0, 3);
  int value = fields[2].toInt();

  // Change simulated traffic demand for a road.
  if (cmd == "DEMAND") {
    demand[road] = constrain(value, 0, 10);
    Serial.println(F("EVENT,DEMAND,0"));
  }

  // Accident: activate/clear the road flag and add queue to represent congestion.
  else if (cmd == "ACCIDENT") {
    accident[road] = (value != 0);
    if (accident[road])
      queueVehicles[road] = min(80, queueVehicles[road] + 5);

    Serial.print(F("EVENT,ACCIDENT,"));
    Serial.println(road);
  }

  // Blockage: reduce road capacity and divert some arrivals in traffic model.
  else if (cmd == "BLOCK") {
    blocked[road] = (value != 0);
    Serial.print(F("EVENT,BLOCK,"));
    Serial.println(road);
  }

  // Pedestrian: request a dedicated phase with all vehicle signals RED.
  else if (cmd == "PED") {
    pedWaiting[road] = (value != 0);
    Serial.print(F("EVENT,PED_REQUEST,"));
    Serial.println(road);
  }

  // VIP: prioritize the selected road; field 4 contains convoy size.
  else if (cmd == "VIP") {
    vip[road] = (value != 0);
    convoySize[road] = vip[road] ? constrain(fields[3].toInt(), 1, 12) : 0;

    Serial.print(F("EVENT,VIP,"));
    Serial.println(road);
  }

  else {
    Serial.println(F("ERR,UNKNOWN_COMMAND"));
  }
}

// -----------------------------------------------------------------------------
// 9. SETUP — RUNS ONCE WHEN ARDUINO STARTS
// -----------------------------------------------------------------------------

void setup() {
  // Configure shift-register control pins as outputs.
  pinMode(SR_DATA, OUTPUT);
  pinMode(SR_CLOCK, OUTPUT);
  pinMode(SR_LATCH, OUTPUT);

  // Configure each ultrasonic sensor's TRIG as OUTPUT and ECHO as INPUT.
  for (byte i = 0; i < 4; i++) {
    pinMode(trigPin[i], OUTPUT);
    pinMode(echoPin[i], INPUT);
    digitalWrite(trigPin[i], LOW);
  }

  Serial.begin(9600); // Start communication with Serial Monitor
  setAllRed();        // Safe initial signal state

  // Initialize timers so the first updates happen correctly.
  phaseStarted = millis();
  modelTick = millis();
  statusTick = millis();

  Serial.println(F("READY,SMART_4_ROAD_UNO"));
}

// -----------------------------------------------------------------------------
// 10. MAIN LOOP — RUNS REPEATEDLY
// -----------------------------------------------------------------------------

void loop() {
  // Read any command typed into Serial Monitor and execute it.
  while (Serial.available()) {
    String line = Serial.readStringUntil('\n');
    processCommand(line);
  }

  updateTrafficModel(); // Read sensors and update simulated queues
  updateController();   // Advance traffic signal phases

  // Send current system status once every second.
  if (millis() - statusTick >= 1000UL) {
    statusTick = millis();
    sendStatus();
  }
}
